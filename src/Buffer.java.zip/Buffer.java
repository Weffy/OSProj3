
public class Buffer {
	static int[] buffer = new int[10];
	static int dataStart = 0;
	static int dataEnd = 0;
	static int numOfItems = 0;

	public synchronized static void produceItem() {
		buffer[dataEnd] = 1; //writing 1's for data
		dataEnd++;
		numOfItems++;
		
	} 
	
	public synchronized static void consumeItem() {
		buffer[dataStart] = 0; //writing 0's for no data
		dataStart++;
		numOfItems--;
	}
}
